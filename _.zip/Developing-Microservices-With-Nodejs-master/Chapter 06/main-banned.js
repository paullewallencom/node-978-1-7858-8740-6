var bannedWords = require('./banned-words')();
