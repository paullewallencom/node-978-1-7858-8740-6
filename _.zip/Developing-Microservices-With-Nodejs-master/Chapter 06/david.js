require('./openweather')

console.log('started');
