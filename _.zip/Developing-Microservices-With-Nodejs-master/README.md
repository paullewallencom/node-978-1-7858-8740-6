## $5 Tech Unlocked 2021!
[Buy and download this Book for only $5 on PacktPub.com](https://www.packtpub.com/product/developing-microservices-with-node-js/9781785887406)
-----
*If you have read this book, please leave a review on [Amazon.com](https://www.amazon.com/gp/product/1785887408).     Potential readers can then use your unbiased opinion to help them make purchase decisions. Thank you. The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Developing-Microservices-With-Nodejs
Chapter-wise code examples

This is the code repository for [Developing Microservices with Node.js](https://www.packtpub.com/web-development/developing-microservices-nodejs?utm_source=github&utm_medium=repository&utm_campaign=9781785887406), published by Packt Publishing. It contains all the supporting code files necessary to work through the book from start to finish.

In order to follow this book, we are going to need to install Node.js, PM2 (it is a package that is installed through npm), and MongoDB. We will also need an editor, like Atom, but any general purpose editor should be enough.

## Related Node.js books
* [Node.js Design Patterns](https://www.packtpub.com/web-development/nodejs-blueprints?utm_source=github&utm_medium=repository&utm_campaign=9781783287314)
* [Mastering Node.js](https://www.packtpub.com/web-development/mastering-nodejs?utm_source=github&utm_medium=repository&utm_campaign=9781782166320)
* [Node.js Blueprints](https://www.packtpub.com/web-development/nodejs-blueprints?utm_source=github&utm_medium=repository&utm_campaign=9781783287338)
